run test.m
function Chess_Segment
function Kmeans_Segment
function Slic_Segment
run draw_figure.m