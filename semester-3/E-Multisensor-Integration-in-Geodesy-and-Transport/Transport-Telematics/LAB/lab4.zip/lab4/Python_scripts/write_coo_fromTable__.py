# -*- coding: cp1252 -*-
# Import native arcgisscripting module
import  sys,arcpy

arcpy.env.overwriteOutput = True

arcpy.AddMessage('----------------------------------')
arcpy.AddMessage('IIGS, University of Stuttgart 2012')
arcpy.AddMessage('----------------------------------')
arcpy.AddMessage('starting Map Matching Script...')

x=[]
y=[]

try:
    paramGDB=str(sys.argv[1])
    paramSR=str(sys.argv[2])
    paramInTable=str(sys.argv[3])

except Exception, ErrorDesc:
    arcpy.addError("Input parameters are incorrect")
    
arcpy.env.Workspace=paramGDB

## read table
## --------------------------------------
desc_table = arcpy.Describe(paramInTable)

rows = arcpy.SearchCursor(paramInTable)

for row in rows:
    
     # Read the Points NEAR_X and NEAR_Y from Table and write to list x,y
     x.append(row.NEAR_X)
     y.append(row.NEAR_Y)
     arcpy.AddMessage("x "+ str(row.NEAR_X)+"y "+str(row.NEAR_Y))
     
count_points=len(x)     
del rows
arcpy.AddMessage(str(count_points)+" are matched!!")
arcpy.AddMessage("--------------------------------------------------------")

## --------- new Feature Class ----------------  ##
fcname="matchedPoint"
arcpy.AddMessage(paramGDB+" "+fcname+" creating...")

target=paramGDB+"\\"+fcname
arcpy.CreateFeatureclass_management(paramGDB,fcname,"POINT","","DISABLED","DISABLED",paramSR)
arcpy.AddMessage( "Create feature class:"+fcname+"    Success!")
pts=arcpy.CreateObject("Point")
## --------- write the coordinates x and y to the new Feature Class -----------##
for index in range(0,count_points):
    arcpy.AddMessage('Adding point '+str(index))

        # create insert cursor
    Inserter_row = arcpy.InsertCursor(target)
        # create update cursor
    Updater_row = arcpy.UpdateCursor(target)

        # assign coordinates to point object
    Points = arcpy.Point(x[index],y[index])

    NewPt = Inserter_row.newRow()
    NewPt.Shape = Points
    Inserter_row.insertRow(NewPt)
        
